const SERVER = "http://127.0.0.1:8000/";

export const displayUserData = (userDataArray) => {
    const userDataDiv = document.getElementById('user-data');
    userDataDiv.innerHTML = '';

    if (Array.isArray(userDataArray) && userDataArray.length > 0) {
        userDataArray.forEach(userData => {
            if (userData && userData.email && userData.sName) {
                userDataDiv.innerHTML += `
                    <div class="col-md-4 mb-4">
                        <div class="card" style="width: 18rem;">
                            <img src="${SERVER + userData.image}" class="card-img-top" alt="${userData.sName}" style="width: 100px; height: 120px;">
                            <div class="card-body">
                                <h5 class="card-title">${userData.sName}</h5>
                                <p class="card-text">Email: ${userData.email}</p>
                                <p class="card-text">Age: ${userData.sAge}</p>
                                <p class="card-text">Address: ${userData.address}</p>
                                <button class="btn btn-primary btn-update" data-id="${userData.id}">Update</button>
                                <button class="btn btn-danger btn-delete" data-id="${userData.id}">Delete</button>
                            </div>
                        </div>
                    </div>
                `;
            }
        });
    } else {
        userDataDiv.innerHTML = '<p>No user data available.</p>';
    }
};
